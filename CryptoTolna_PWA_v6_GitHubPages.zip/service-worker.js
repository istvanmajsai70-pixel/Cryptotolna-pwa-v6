
const CACHE_NAME = 'cryptotolna-v6-cache-v1';
const ASSETS = ['./','./index.html','./market.html','./about.html','./contact.html','./style.css','./app.js','./manifest.json'];
self.addEventListener('install', evt => { evt.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))); self.skipWaiting(); });
self.addEventListener('activate', evt => { evt.waitUntil(clients.claim()); });
self.addEventListener('fetch', evt => {
  const req = evt.request; const url = new URL(req.url);
  if(url.hostname.includes('api.coingecko.com')){
    evt.respondWith(fetch(req).then(res=>{ const copy=res.clone(); caches.open(CACHE_NAME).then(c=>c.put(req,copy)); return res; }).catch(()=>caches.match(req).then(cached=>cached || caches.match('./index.html'))));
    return;
  }
  evt.respondWith(caches.match(req).then(cached=>cached || fetch(req).catch(()=>caches.match('./index.html'))));
});