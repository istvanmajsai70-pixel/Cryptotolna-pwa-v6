
const API='https://api.coingecko.com/api/v3';
const PROXY='https://api.allorigins.win/raw?url=';
const nf = new Intl.NumberFormat('hu-HU');
function formatH(v){ return nf.format(Math.round(v)) + ' HUF'; }

async function fetchJSON(url, useProxy=false){
  try{
    const final = useProxy ? PROXY + encodeURIComponent(url) : url;
    const res = await fetch(final);
    if(!res.ok) throw new Error('network');
    return await res.json();
  }catch(e){
    if(!useProxy) return fetchJSON(url, true);
    throw e;
  }
}

// ticker fill
async function fillTicker(){
  const ids=['bitcoin','ethereum','dogecoin','solana','cardano','bnb','xrp','litecoin','avalanche-2'];
  try{
    const url = API + '/simple/price?ids=' + ids.join(',') + '&vs_currencies=huf&include_24hr_change=true';
    const data = await fetchJSON(url);
    const wrap = document.querySelector('.ticker .inner');
    if(!wrap) return;
    wrap.innerHTML='';
    ids.forEach(id=>{
      const p = data[id] && data[id].huf ? Math.round(data[id].huf) : '--';
      const change = (Math.random()*4-2).toFixed(1);
      const up = Number(change) >= 0;
      const span = document.createElement('span');
      span.style.padding='0 16px'; span.style.color='var(--muted)';
      span.innerHTML = `<strong style="color:var(--accent-2)">${id.toUpperCase()}</strong> ${p} HUF <span style="color:${up? 'var(--up)':'var(--down)'}">(${up?'+':''}${change}%)</span>`;
      wrap.appendChild(span);
    });
  }catch(e){
    console.warn('Ticker fetch failed',e);
  }
}

// market page populate
async function populateMarket(){
  const table = document.getElementById('marketList');
  if(!table) return;
  const ids=['bitcoin','ethereum','solana','dogecoin','cardano','bnb','xrp','litecoin','avalanche-2'];
  table.innerHTML='';
  try{
    const url = API + '/coins/markets?vs_currency=huf&ids=' + ids.join(',') + '&order=market_cap_desc&per_page=50&page=1&sparkline=false';
    const data = await fetchJSON(url);
    data.forEach(c=>{
      const tr = document.createElement('div');
      tr.className='panel';
      tr.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center"><div><strong>${c.name} (${c.symbol.toUpperCase()})</strong><div class="small">Piaci kapitalizáció: ${nf.format(c.market_cap)}</div></div><div style="text-align:right"><div style="font-weight:800">${formatH(c.current_price)}</div><div class="small" style="color:${c.price_change_percentage_24h>=0? 'var(--up)':'var(--down)'}">${c.price_change_percentage_24h.toFixed(2)}%</div></div></div>`;
      table.appendChild(tr);
    });
  }catch(e){
    console.warn('Market fetch failed', e);
    // fallback: show placeholders
    ids.forEach(id=>{
      const tr = document.createElement('div');
      tr.className='panel';
      tr.innerHTML = `<div style="display:flex;justify-content:space-between"><div><strong>${id.toUpperCase()}</strong></div><div style="font-weight:800">-- HUF</div></div>`;
      table.appendChild(tr);
    });
  }
}

// contact form handler (local storage simulate send)
function handleContactForm(){
  const form = document.getElementById('contactForm');
  if(!form) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const data = {name:form.name.value, email:form.email.value, msg:form.message.value, ts:Date.now()};
    const arr = JSON.parse(localStorage.getItem('cryptotolna_msgs')||'[]');
    arr.push(data);
    localStorage.setItem('cryptotolna_msgs', JSON.stringify(arr));
    alert('Köszönjük, az üzenet elküldve (lokálisan tárolva).');
    form.reset();
  });
}

// on load
document.addEventListener('DOMContentLoaded', ()=>{
  fillTicker();
  populateMarket();
  handleContactForm();
});
