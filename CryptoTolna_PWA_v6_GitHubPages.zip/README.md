# CryptoTolna PWA (GitHub Pages verzió)

Ez a verzió teljesen kompatibilis a **GitHub Pages** szolgáltatással.

## 📦 Telepítés lépései

1. Jelentkezz be a GitHub fiókodba.
2. Hozz létre egy új repository-t (pl. `CryptoTolna_PWA_v6` néven).
3. Másold fel ennek a mappának a tartalmát a repo gyökerébe.
4. GitHub → **Settings → Pages** → válaszd ki a branch-et (`main` vagy `master`), majd mentsd.
5. Az oldal elérhető lesz itt:  
   `https://<felhasználóneved>.github.io/<repo-neve>/`

## 🌐 Fő fájlok

- `index.html` – kezdőlap
- `market.html`, `about.html`, `contact.html` – további oldalak
- `manifest.json` – PWA beállítás
- `service-worker.js` – offline cache és API kezelés
- `icons/` – alkalmazás ikonok

## ⚠️ Megjegyzés

- Az összes útvonal relatív, így nem szükséges módosítani a GitHub Pages-hez.
- A PWA funkciók (telepítés, offline használat) csak **HTTPS** alatt működnek, amit a GitHub automatikusan biztosít.
