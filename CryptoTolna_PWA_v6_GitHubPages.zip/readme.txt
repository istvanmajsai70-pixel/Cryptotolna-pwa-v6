
CryptoTolna PWA v6 (Többlapos, Android-ready)
--------------------------------------------
Fájlok:
- index.html (Főoldal)
- market.html (Piac)
- about.html (Rólunk)
- contact.html (Kapcsolat)
- style.css
- app.js
- manifest.json
- service-worker.js
- icons/ (PNG 192,256,512)
Telepítés Netlify-ra:
1) https://app.netlify.com/drop
2) Húzd be a kibontott mappa tartalmát
3) Netlify HTTPS URL-t ad; nyisd meg, majd Chrome -> Add to Home screen
Tesztelés lokálisan:
python -m http.server 8000
open http://localhost:8000
